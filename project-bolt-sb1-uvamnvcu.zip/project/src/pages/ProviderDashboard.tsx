import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

interface Booking {
  id: string;
  client: {
    full_name: string;
    phone: string;
  };
  service: {
    name: string;
    base_price: number;
  };
  scheduled_time: string;
  address: string;
  notes: string;
  status: string;
}

export default function ProviderDashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchBookings();
    }
  }, [user]);

  const fetchBookings = async () => {
    const { data: providerData, error: providerError } = await supabase
      .from('service_providers')
      .select('id')
      .eq('user_id', user?.id)
      .single();

    if (providerError || !providerData) {
      toast.error('Error fetching provider data');
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('bookings')
      .select(`
        id,
        scheduled_time,
        address,
        notes,
        status,
        client:profiles(full_name, phone),
        service:services(name, base_price)
      `)
      .eq('provider_id', providerData.id)
      .order('scheduled_time', { ascending: true });

    if (error) {
      toast.error('Error fetching bookings');
    } else {
      setBookings(data);
    }
    setLoading(false);
  };

  const updateBookingStatus = async (bookingId: string, newStatus: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status: newStatus })
      .eq('id', bookingId);

    if (error) {
      toast.error('Error updating booking status');
    } else {
      toast.success('Booking status updated');
      fetchBookings();
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Provider Dashboard</h1>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {bookings.map((booking) => (
            <li key={booking.id} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">
                    {booking.service.name}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Client: {booking.client.full_name}
                  </p>
                  <p className="mt-1 text-sm text-gray-500">
                    Phone: {booking.client.phone}
                  </p>
                  <p className="mt-1 text-sm text-gray-500">
                    Date: {new Date(booking.scheduled_time).toLocaleString()}
                  </p>
                  <p className="mt-1 text-sm text-gray-500">
                    Address: {booking.address}
                  </p>
                  {booking.notes && (
                    <p className="mt-1 text-sm text-gray-500">
                      Notes: {booking.notes}
                    </p>
                  )}
                </div>
                <div className="ml-6">
                  <select
                    value={booking.status}
                    onChange={(e) => updateBookingStatus(booking.id, e.target.value)}
                    className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-md"
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            </li>
          ))}
          {bookings.length === 0 && (
            <li className="p-6 text-center text-gray-500">
              No bookings found
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}